﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class Car : Vehicle
    {
        public Car()
        {
            this.DefaultFuelConsumption = 3;
        }
    }
}
